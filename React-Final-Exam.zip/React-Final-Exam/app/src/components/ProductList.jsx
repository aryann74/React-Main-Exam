import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ProductItem from './ProductItem';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/posts?_limit=6')
      .then(response => {
        setProducts(response.data.map(product => ({
          id: product.id,
          title: product.title,
          price: Math.floor(Math.random() * 100) + 1, // Random price
          image: `https://via.placeholder.com/150/92c952`, // Placeholder image
          category: 'Sample Category'
        })));
        setLoading(false);
      })
      .catch(error => console.error('Error fetching products:', error));
  }, []);

  const deleteProduct = (id) => {
    setProducts(products.filter(product => product.id !== id));
  };

  if (loading) {
    return <div className="container mt-4 text-center"><p>Loading products...</p></div>;
  }

  return (
    <div className="container mt-4">
      <h2>Product List</h2>
      <div className="row">
        {products.map(product => (
          <ProductItem key={product.id} product={product} onDelete={deleteProduct} />
        ))}
      </div>
    </div>
  );
};

export default ProductList;
